create function gettopsportteams(sportid integer, number integer)
    returns TABLE(sport_id integer, sport_team_id integer, sport_team_name character varying, sport_team_rate double precision)
    language plpgsql
as
$$
            BEGIN
                IF number = 0 THEN
                return query (select sport_team_sport.fk_sport_id, sport_team.sport_team_id, sport_team.name, sport_team.average_rate from sport_team
                    join sport_team_sport on sport_team.sport_team_id = sport_team_sport.fk_sport_team_id and sport_team_sport.fk_sport_id = sportId
                    order by sport_team.average_rate desc);
                ELSE
                return query (select sport_team_sport.fk_sport_id, sport_team.sport_team_id, sport_team.name, sport_team.average_rate from sport_team
                    join sport_team_sport on sport_team.sport_team_id = sport_team_sport.fk_sport_team_id and sport_team_sport.fk_sport_id = sportId
                    order by sport_team.average_rate desc limit number);
                END IF;
                EXCEPTION
                    WHEN duplicate_function THEN
                    NULL;
            END;
            $$;

alter function gettopsportteams(integer, integer) owner to postgres;

