create function getcompetitionsforsportsman(person_id integer)
    returns TABLE(sportsman_id integer, competition_id integer, competition_name character varying, competition_date date, competition_place character varying, competition_prestige smallint, sport_id integer, sport_name character varying, preparation_id integer, rating_diff smallint)
    language plpgsql
as
$$
            BEGIN
                return query (select sportsman.sportsman_id, competition.competition_id, competition.name, competition.date_of_event, competition.place, competition.prestige, sport.sport_id, sport.name, sportsman_competition.fk_preparation_id, sportsman_competition.rating_difference from competition
                    join sportsman_competition on sportsman_competition.fk_competition_id = competition.competition_id
                    join sportsman on sportsman.sportsman_id = sportsman_competition.fk_sportsman_id and sportsman.sportsman_id = person_id
                    join sport on competition.fk_sport_id = sport.sport_id );
                EXCEPTION
                    WHEN duplicate_function THEN
                    NULL;
            END;
            $$;

alter function getcompetitionsforsportsman(integer) owner to postgres;

