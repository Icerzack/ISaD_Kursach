create function gettoppreparations(number integer)
    returns TABLE(preparation_id integer, training_name character varying, baa_name character varying, preparation_rate double precision)
    language plpgsql
as
$$
            BEGIN
                IF number = 0 then
                return query (select preparation.preparation_id, training.name, preparation_baa.complex_name, preparation_rate.effectiveness from preparation
                    join training on preparation.fk_training_id = training.training_id
                    join preparation_baa on preparation.preparation_id = preparation_baa.fk_preparation_id
                    join baa on preparation_baa.fk_baa_id = baa.baa_id
                    join preparation_rate on preparation.preparation_id = preparation_rate.fk_preparation_id
                    order by preparation_rate.effectiveness desc);
                ELSE
                return query (select preparation.preparation_id, training.name, preparation_baa.complex_name, preparation_rate.effectiveness from preparation
                    join training on preparation.fk_training_id = training.training_id
                    join preparation_baa on preparation.preparation_id = preparation_baa.fk_preparation_id
                    join baa on preparation_baa.fk_baa_id = baa.baa_id
                    join preparation_rate on preparation.preparation_id = preparation_rate.fk_preparation_id
                    order by preparation_rate.effectiveness desc limit number);
                END IF;
                EXCEPTION
                    WHEN duplicate_function THEN
                    NULL;
            END;
            $$;

alter function gettoppreparations(integer) owner to postgres;

