create function gettopbaasbyrating(number integer)
    returns TABLE(baa_id integer, baa_name character varying, baa_manufacturer character varying, baa_description text, baa_uses integer, baa_rate integer)
    language plpgsql
as
$$
            BEGIN
                IF number = 0 then
                return query (select baa.baa_id, name, manufacturer, description, baa_rate.number_uses, baa_rate.all_time_rate_difference from baa
                    join baa_rate on baa.baa_id = baa_rate.fk_baa_id order by baa_rate.all_time_rate_difference desc);
                ELSE
                return query (select baa.baa_id, name, manufacturer, description, baa_rate.number_uses, baa_rate.all_time_rate_difference from baa
                    join baa_rate on baa.baa_id = baa_rate.fk_baa_id order by baa_rate.all_time_rate_difference desc limit number);
                END IF;
                EXCEPTION
                    WHEN duplicate_function THEN
                    NULL;
            END;
            $$;

alter function gettopbaasbyrating(integer) owner to postgres;

